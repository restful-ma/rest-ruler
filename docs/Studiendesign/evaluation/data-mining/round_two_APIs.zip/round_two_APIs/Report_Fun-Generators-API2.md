REST API Specification Report
=============================
| Line No. | Line               | Rule Violated                                     | Category | Severity | Rule Type | Software Quality Attributes | Improvement Suggestion                |
| -------- | ------------------ | ------------------------------------------------- | -------- | -------- | --------- | --------------------------- | ------------------------------------- |
| 192      | /trivia/categories | A singular noun should be used for document names | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY  | Use singular nouns for document names |
| 234      | /trivia/random     | A singular noun should be used for document names | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY  | Use singular nouns for document names |