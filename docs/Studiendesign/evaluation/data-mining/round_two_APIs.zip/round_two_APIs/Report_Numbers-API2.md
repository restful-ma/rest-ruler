REST API Specification Report
=============================
| Line No. | Line               | Rule Violated                                     | Category | Severity | Rule Type | Software Quality Attributes | Improvement Suggestion                |
| -------- | ------------------ | ------------------------------------------------- | -------- | -------- | --------- | --------------------------- | ------------------------------------- |
| 42       | /generate/integers | A singular noun should be used for document names | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY  | Use singular nouns for document names |