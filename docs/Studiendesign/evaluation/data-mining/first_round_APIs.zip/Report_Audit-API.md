REST API Specification Report
=============================
| Line No. | Line | Rule Violated | Category | Severity | Rule Type | Software Quality Attributes | Improvement Suggestion |
| -------- | ---- | ------------- | -------- | -------- | --------- | --------------------------- | ---------------------- |
