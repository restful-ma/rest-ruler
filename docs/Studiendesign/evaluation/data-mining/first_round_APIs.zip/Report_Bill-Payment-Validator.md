REST API Specification Report
=============================
| Line No. | Line            | Rule Violated                                                 | Category | Severity | Rule Type | Software Quality Attributes    | Improvement Suggestion                                 |
| -------- | --------------- | ------------------------------------------------------------- | -------- | -------- | --------- | ------------------------------ | ------------------------------------------------------ |
| 33       | /isRoutingValid | Hyphens (-) should be used to improve the readability of URIs | URIS     | ERROR    | STATIC    | COMPATIBILITY, MAINTAINABILITY | Use hyphens to improve the readability of the segments |
| 33       | /isRoutingValid | Lowercase letters should be preferred in URI paths            | URIS     | ERROR    | STATIC    | COMPATIBILITY, MAINTAINABILITY | Change uppercase letters to lowercase letters          |