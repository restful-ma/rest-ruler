REST API Specification Report
=============================
| Line No. | Line               | Rule Violated                                                 | Category | Severity | Rule Type | Software Quality Attributes    | Improvement Suggestion                                 |
| -------- | ------------------ | ------------------------------------------------------------- | -------- | -------- | --------- | ------------------------------ | ------------------------------------------------------ |
| 30       | /nbcer/certificate | A plural noun should be used for collection or store names    | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY     | Use plural nouns for collection or store names         |
| 30       | /nbcer/certificate | Hyphens (-) should be used to improve the readability of URIs | URIS     | ERROR    | STATIC    | COMPATIBILITY, MAINTAINABILITY | Use hyphens to improve the readability of the segments |