REST API Specification Report
=============================
| Line No. | Line               | Rule Violated                                                 | Category | Severity | Rule Type | Software Quality Attributes    | Improvement Suggestion                                 |
| -------- | ------------------ | ------------------------------------------------------------- | -------- | -------- | --------- | ------------------------------ | ------------------------------------------------------ |
| 58       | /v1/violatingSites | Hyphens (-) should be used to improve the readability of URIs | URIS     | ERROR    | STATIC    | COMPATIBILITY, MAINTAINABILITY | Use hyphens to improve the readability of the segments |
| 58       | /v1/violatingSites | Lowercase letters should be preferred in URI paths            | URIS     | ERROR    | STATIC    | COMPATIBILITY, MAINTAINABILITY | Change uppercase letters to lowercase letters          |
| 114      | /v1/{name}         | A plural noun should be used for collection or store names    | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY     | Use singular nouns for document names                  |
| 114      | /v1/{name}         | Hyphens (-) should be used to improve the readability of URIs | URIS     | ERROR    | STATIC    | COMPATIBILITY, MAINTAINABILITY | Use hyphens to improve the readability of the segments |