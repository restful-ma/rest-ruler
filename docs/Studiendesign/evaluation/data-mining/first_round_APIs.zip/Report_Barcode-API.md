REST API Specification Report
=============================
| Line No. | Line                  | Rule Violated                                              | Category | Severity | Rule Type | Software Quality Attributes | Improvement Suggestion                         |
| -------- | --------------------- | ---------------------------------------------------------- | -------- | -------- | --------- | --------------------------- | ---------------------------------------------- |
| 47       | /barcode/decode       | A plural noun should be used for collection or store names | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY  | Use plural nouns for collection or store names |
| 105      | /barcode/decode/types | A plural noun should be used for collection or store names | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY  | Use plural nouns for collection or store names |
| 105      | /barcode/decode/types | A singular noun should be used for document names          | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY  | Use singular nouns for document names          |
| 144      | /barcode/encode       | A plural noun should be used for collection or store names | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY  | Use plural nouns for collection or store names |
| 235      | /barcode/encode/types | A plural noun should be used for collection or store names | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY  | Use plural nouns for collection or store names |
| 235      | /barcode/encode/types | A singular noun should be used for document names          | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY  | Use singular nouns for document names          |