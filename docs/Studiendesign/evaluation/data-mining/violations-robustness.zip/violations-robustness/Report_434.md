REST API Specification Report
=============================
| Line No. | Line           | Rule Violated                                                 | Category | Severity | Rule Type | Software Quality Attributes    | Improvement Suggestion                                 |
| -------- | -------------- | ------------------------------------------------------------- | -------- | -------- | --------- | ------------------------------ | ------------------------------------------------------ |
| 34       | /v1/agreements | Hyphens (-) should be used to improve the readability of URIs | URIS     | ERROR    | STATIC    | COMPATIBILITY, MAINTAINABILITY | Use hyphens to improve the readability of the segments |