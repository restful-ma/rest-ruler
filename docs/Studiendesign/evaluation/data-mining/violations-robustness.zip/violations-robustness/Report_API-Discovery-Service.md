REST API Specification Report
=============================
| Line No. | Line                       | Rule Violated                                              | Category | Severity | Rule Type | Software Quality Attributes | Improvement Suggestion                |
| -------- | -------------------------- | ---------------------------------------------------------- | -------- | -------- | --------- | --------------------------- | ------------------------------------- |
| 113      | /apis/{api}/{version}/rest | A plural noun should be used for collection or store names | URIS     | ERROR    | STATIC    | USABILITY, MAINTAINABILITY  | Use singular nouns for document names |